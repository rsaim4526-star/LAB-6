// NAME:Sheraz Ahmed
// ROLL NUM: L1F26BSCS0097
#include <iostream>
using namespace std;

int main()
{
    int dayNumber;

    cout << "Enter day number (1-7): ";
    cin >> dayNumber;

    switch (dayNumber)
    {
    case 1:
        cout << "Day: Monday";
        break;

    case 2:
        cout << "Day: Tuesday";
        break;

    case 3:
        cout << "Day: Wednesday";
        break;

    case 4:
        cout << "Day: Thursday";
        break;

    case 5:
        cout << "Day: Friday";
        break;

    case 6:
        cout << "Day: Saturday";
        break;

    case 7:
        cout << "Day: Sunday";
        break;

    default:
        cout << "Invalid day number";
    }

    return 0;
}