// NAME:Sheraz Ahmed
// ROLL NUM: L1F26BSCS0097
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    char grade;
    double gradePoint;

    cout << "Enter your grade (A/B/C/D/F): ";
    cin >> grade;

    switch (grade)
    {
    case 'A':
    case 'a':
        gradePoint = 4.0;
        cout << "Remarks: Excellent work" << endl;
        break;

    case 'B':
    case 'b':
        gradePoint = 3.0;
        cout << "Remarks: Good" << endl;
        break;

    case 'C':
    case 'c':
        gradePoint = 2.0;
        cout << "Remarks: Satisfactory" << endl;
        break;

    case 'D':
    case 'd':
        gradePoint = 1.0;
        cout << "Remarks: Needs improvement" << endl;
        break;

    case 'F':
    case 'f':
        gradePoint = 0.0;
        cout << "Remarks: Fail" << endl;
        break;

    default:
        gradePoint = 0.0;
        cout << "Invalid grade" << endl;
    }

    return 0;
}