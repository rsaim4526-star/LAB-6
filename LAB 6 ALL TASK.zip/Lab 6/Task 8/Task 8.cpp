// NAME:Sheraz Ahmed
// ROLL NUM: L1F26BSCS0097
#include <iostream>
using namespace std;

int main()
{
    int sideA, sideB, sideC;

    cout << "Enter first side: ";
    cin >> sideA;

    cout << "Enter second side: ";
    cin >> sideB;

    cout << "Enter third side: ";
    cin >> sideC;

    if (sideA > 0)
    {
        if (sideB > 0)
        {
            if (sideC > 0)
            {
                if (sideA + sideB > sideC)
                {
                    if (sideA + sideC > sideB)
                    {
                        if (sideB + sideC > sideA)
                        {
                            cout << "Valid triangle" << endl;

                            if (sideA == sideB)
                            {
                                if (sideB == sideC)
                                {
                                    cout << "Type: Equilateral";
                                }
                                else
                                {
                                    cout << "Type: Isosceles";
                                }
                            }
                            else
                            {
                                if (sideA == sideC)
                                {
                                    cout << "Type: Isosceles";
                                }
                                else
                                {
                                    if (sideB == sideC)
                                    {
                                        cout << "Type: Isosceles";
                                    }
                                    else
                                    {
                                        cout << "Type: Scalene";
                                    }
                                }
                            }
                        }
                        else
                        {
                            cout << "Not a valid triangle: two sides must add up to more than the third";
                        }
                    }
                    else
                    {
                        cout << "Not a valid triangle: two sides must add up to more than the third";
                    }
                }
                else
                {
                    cout << "Not a valid triangle: two sides must add up to more than the third";
                }
            }
            else
            {
                cout << "Invalid: every side must be greater than 0";
            }
        }
        else
        {
            cout << "Invalid: every side must be greater than 0";
        }
    }
    else
    {
        cout << "Invalid: every side must be greater than 0";
    }

    return 0;
}